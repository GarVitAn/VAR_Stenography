﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Steganography {

    public class Koch3 {

        private readonly DecodingForm form;

        public byte[] hideInf;
        private const int P = 25;
        public int mKey = 0;
        public int sizeSegment = 0;
        public string filename = "";
        public Bitmap image1 = null;

        private Point p1;
        private Point p2;

        private ImageFormat imFormat;

        public Koch3(DecodingForm form) {
            this.form = form;
        }

        public void InLining() {
            try {
                var workImage = new Bitmap(image1);

                BlockPanel(true);
                SendMessToForm("Начало встраивания");
                InitializationPoint();
                string ex = filename.Substring(filename.LastIndexOf(".", StringComparison.Ordinal) + 1);
                SendMessToForm("Расширение контейнера: " + ex);
                SendMessToForm("Размер блоков = " + sizeSegment);
                SendMessToForm("Точки встраивания: (" + p1.X + "; " + p1.Y + ")  (" + p2.X + "; " + p2.Y + ")");
                SendMessToForm("Ключ для извлечения: " + hideInf.Length);

                imFormat = ex switch {
                    "bmp" => ImageFormat.Bmp,
                    "png" => ImageFormat.Png,
                    "Bmp" => ImageFormat.Bmp,
                    "Png" => ImageFormat.Png,
                    _ => imFormat
                };

                if (workImage.Width % sizeSegment != 0 || workImage.Height % sizeSegment != 0)
                    Trim(ref workImage, sizeSegment);
                
                int sizeX = workImage.Width;
                int sizeY = workImage.Height;
                var R = new byte[sizeX, sizeY];
                var G = new byte[sizeX, sizeY];
                var B = new byte[sizeX, sizeY];
                for (var i = 0; i < sizeX; i++)
                    for (var j = 0; j < sizeY; j++) {
                        R[i, j] = workImage.GetPixel(i, j).R;
                        G[i, j] = workImage.GetPixel(i, j).G;
                        B[i, j] = workImage.GetPixel(i, j).B;
                    }

                var sepB = new List<byte[,]>();
                Separation(B, ref sepB, sizeX, sizeY, sizeSegment);
                SendMessToForm("Вычисление ДКП");
                List<double[,]> DKP = sepB.Select(Koch3.DKP).ToList();

                SendMessToForm("Встраивание информации");
                InLiningMess(hideInf, ref DKP, P, p1, p2);

                SendMessToForm("Вычисление ОДКП");
                List<double[,]> ODKP = DKP.Select(Koch3.ODKP).ToList();

                var newB = new double[sizeX, sizeY];
                Integration(ODKP, ref newB, sizeX, sizeY, sizeSegment);
                newB = Normalization(newB);

                for (var i = 0; i < sizeX; i++)
                    for (var j = 0; j < sizeY; j++)
                        workImage.SetPixel(i, j, Color.FromArgb(R[i, j], G[i, j], (byte)Math.Round(newB[i, j])));

                SendMessToForm("Встраивание завершено!");

                string name = filename.Substring(filename.LastIndexOf("\\", StringComparison.Ordinal) + 1);
                string path = Path.GetDirectoryName(filename);
                File.WriteAllText(path + "\\Зашифрованная_картинка-" + name + ".txt", Convert.ToString(hideInf.Length), Encoding.Default);
                path += "\\Зашифрованная_картинка-" + name;
                workImage.Save(path, imFormat);

                SendMessToForm("Сохранено: " + path);
            } catch (Exception e) {
                SendMessToForm("Ошибка встраивания: " + e.Message);
            } finally {
                BlockPanel(false);
            }
        }

        public void Extraction() {
            try {
                BlockPanel(true);
                SendMessToForm("Начало извлечения");
                InitializationPoint();
                SendMessToForm("размер блоков = " + sizeSegment);
                SendMessToForm("точки встраивания: (" + p1.X + "; " + p1.Y + ")  (" + p2.X + "; " + p2.Y + ")");
                SendMessToForm("Ключ: " + mKey);

                var image = (Bitmap)Image.FromFile(filename);
                int sizeX = image.Width;
                int sizeY = image.Height;
                var R = new byte[sizeX, sizeY];
                var G = new byte[sizeX, sizeY];
                var B = new byte[sizeX, sizeY];
                for (var i = 0; i < sizeX; i++) {
                    for (var j = 0; j < sizeY; j++) {
                        R[i, j] = image.GetPixel(i, j).R;
                        G[i, j] = image.GetPixel(i, j).G;
                        B[i, j] = image.GetPixel(i, j).B;
                    }
                }

                var sepB = new List<byte[,]>();
                Separation(B, ref sepB, sizeX, sizeY, sizeSegment);
                SendMessToForm("Вычисление ДКП");

                List<double[,]> DKP = sepB.Select(Koch3.DKP).ToList();

                SendMessToForm("Извлечение информации");
                int size = mKey;
                var stringBits = "";
                var message = new List<byte>();
                int key = mKey;
                var allPos = new List<int>();
                for (var i = 0; i < DKP.Count; i++)
                    allPos.Add(i);

                while (size > 0) {
                    key = MultiTransfer(key, allPos.Count);
                    int pos = allPos[key];
                    allPos.RemoveAt(key);
                    double AbsPoint1 = Math.Abs(DKP[pos][p1.X, p1.Y]);
                    double AbsPoint2 = Math.Abs(DKP[pos][p2.X, p2.Y]);
                    if (AbsPoint1 > AbsPoint2)
                        stringBits += "0";

                    if (AbsPoint1 < AbsPoint2)
                        stringBits += "1";

                    if (stringBits.Length != 8)
                        continue;

                    message.Add(Convert.ToByte(Convert.ToInt32(stringBits, 2)));
                    stringBits = "";
                    size--;
                }

                var time = DateTime.Now.ToString("dd.MM.yyyy");
                var time1 = DateTime.Now.ToString("HH.mm.ss");

                string path = @"Декодирование\" + time + "_" + time1;
                bool exists1 = Directory.Exists(path);
                if (!exists1)
                    Directory.CreateDirectory(path);

                path += "\\Изображение_с_сообщением." + Path.GetFileName(filename);
                File.Copy(filename, path, true);
                
                image.Dispose();
                string[] ex = Processing(message);

                var message2 = new List<byte>();
                for (int i = ex[0].Length + 1; i < message.Count - ex[0].Length - 1; i++)
                    message2.Add(message[i]);


                SendMessToForm("Извлечение завершено!");
                SendMessToForm("Извлечено " + message2.Count + " байт");
                path = @"Декодирование\" + time + "_" + time1;
                path += "\\Сообщение_из_изображения." + ex[0];
                if (SaveMessage(message2, path))
                    SendMessToForm("Сохранено: " + path);
            } catch (Exception) {
                SendMessToForm("Не удалось извлечь сообщение!\n\n");
            } finally {
                BlockPanel(false);
            }
        }

        private bool SaveMessage(List<byte> message, string path) {
            try {
                File.WriteAllBytes(path, message.ToArray());
                return true;
            } catch (Exception) {
                SendMessToForm("Не удалось извлечь сообщение!");
                return false;
            }
        }

        private static string[] Processing(IReadOnlyList<byte> message) {
            var ex = new string[2];
            string tmp = message.Select(Convert.ToInt32).TakeWhile(n => n != 126).Aggregate("", (current, n) => current + Convert.ToChar(n));

            var tmp2 = "";
            for (int i = message.Count - 1; i >= 0; i--) {
                var n = Convert.ToInt32(message[i]);
                if (n == 126)
                    break;

                tmp2 += Convert.ToChar(n);
            }

            var tmp3 = "";
            for (int i = tmp2.Length - 1; i >= 0; i--)
                tmp3 += tmp2[i];

            if (tmp.Length < 10)
                ex[0] = tmp;
            else
                ex[0] = tmp.Substring(0, 9);

            if (tmp3.Length < 10)
                ex[1] = tmp3;
            else
                ex[1] = tmp3.Substring(0, 9);

            return ex;
        }

        private static void Trim(ref Bitmap image, int sizeSegment) {
            int x = image.Width % sizeSegment;
            int y = image.Height % sizeSegment;
            var newSize = new Size(image.Width - x, image.Height - y);
            var b = new Bitmap(newSize.Width, newSize.Height);
            for (var i = 0; i < b.Width; i++)
                for (var j = 0; j < b.Height; j++)
                    b.SetPixel(i, j, image.GetPixel(i, j));
            image = b;
        }

        private static void InLiningMess(IReadOnlyCollection<byte> message, ref List<double[,]> DKP, int P, Point p1, Point p2) {
            int key = message.Count;
            var allPos = new List<int>();
            for (var i = 0; i < DKP.Count; i++) {
                allPos.Add(i);
            }

            foreach (byte t in message) {
                var conv = new Converter(t);
                for (var j = 0; j < 8; j++) {
                    key = MultiTransfer(key, allPos.Count);
                    int pos = allPos[key];
                    allPos.RemoveAt(key);
                    double AbsPoint1 = Math.Abs(DKP[pos][p1.X, p1.Y]);
                    double AbsPoint2 = Math.Abs(DKP[pos][p2.X, p2.Y]);
                    int z1 = 1, z2 = 1;
                    if (DKP[pos][p1.X, p1.Y] < 0)
                        z1 = -1;

                    if (DKP[pos][p2.X, p2.Y] < 0)
                        z2 = -1;

                    if ((int)conv.bits[j] == 0)
                        if (AbsPoint1 - AbsPoint2 <= P)
                            AbsPoint1 = P + AbsPoint2 + 1;
                    
                    if ((int)conv.bits[j] == 1)
                        if (AbsPoint1 - AbsPoint2 >= -P)
                            AbsPoint2 = P + AbsPoint1 + 1;

                    DKP[pos][p1.X, p1.Y] = z1 * AbsPoint1;
                    DKP[pos][p2.X, p2.Y] = z2 * AbsPoint2;
                }
            }
        }

        private static int MultiTransfer(long x, int maxSize) {
            const long a = 0xffffda61L;
            x = a * (x & 65535) + (x >> 16);
            x = Math.Abs((int)x);
            if (x >= maxSize)
                x %= maxSize;

            return (int)x;
        }

        private static void Separation(byte[,] B, ref List<byte[,]> C, int sizeX, int sizeY, int sizeSegment) {
            int Nx = sizeX / sizeSegment;
            int Ny = sizeY / sizeSegment;
            for (var i = 0; i < Nx; i++) {
                int startX = i * sizeSegment;
                int endX = startX + sizeSegment - 1;
                for (var j = 0; j < Ny; j++) {
                    int startY = j * sizeSegment;
                    int endY = startY + sizeSegment - 1;
                    C.Add(SubMatrix(B, startX, endX, startY, endY));
                }
            }
        }

        private static byte[,] SubMatrix(byte[,] B, int startX, int endX, int startY, int endY) {
            int Nx = endX - startX + 1;
            int Ny = endY - startY + 1;
            var res = new byte[Ny, Nx];
            for (var i = 0; i < Nx; i++)
                for (var j = 0; j < Ny; j++)
                    res[i, j] = B[i + startX, j + startY];

            return res;
        }

        private static void Insert(ref double[,] newB, double[,] tmp, int startX, int endX, int startY, int endY) {
            var u = 0;
            for (int i = startX; i < endX + 1; i++) {
                var v = 0;
                for (int j = startY; j < endY + 1; j++) {
                    newB[i, j] = tmp[u, v];
                    v++;
                }
                u++;
            }
        }

        private static void Integration(List<double[,]> ODKP, ref double[,] newB, int sizeX, int sizeY, int sizeSegment) {
            double[][,] tmp = ODKP.ToArray();
            int Nx = sizeX / sizeSegment;
            int Ny = sizeY / sizeSegment;
            var k = 0;
            for (var i = 0; i < Nx; i++) {
                int startX = i * sizeSegment;
                int endX = startX + sizeSegment - 1;
                for (var j = 0; j < Ny; j++) {
                    int startY = j * sizeSegment;
                    int endY = startY + sizeSegment - 1;
                    if (k > tmp.GetLength(0))
                        throw new IndexOutOfRangeException();

                    Insert(ref newB, tmp[k], startX, endX, startY, endY);
                    k++;
                }
            }
        }

        private void InitializationPoint() {
            switch (sizeSegment) {
                case 2:
                    p1 = new Point(1, 0);
                    p2 = new Point(1, 1);
                    break;
                case 4:
                    p1 = new Point(3, 2);
                    p2 = new Point(2, 3);
                    break;
                case 8:
                    p1 = new Point(6, 3);
                    p2 = new Point(3, 6);
                    break;
            }
        }

        private static double[,] DKP(byte[,] C) {
            int n = C.GetLength(0);
            var result = new double[n, n];
            for (var v = 0; v < n; v++) {
                for (var u = 0; u < n; u++) {
                    double V;
                    if (v == 0)
                        V = 1.0 / Math.Sqrt(2);
                    else
                        V = 1;

                    double U;
                    if (u == 0)
                        U = 1.0 / Math.Sqrt(2);
                    else
                        U = 1;

                    double temp = 0;
                    for (var i = 0; i < n; i++)
                        for (var j = 0; j < n; j++)
                            temp += C[i, j] * Math.Cos(Math.PI * v * (2 * i + 1) / (2 * n)) * Math.Cos(Math.PI * u * (2 * j + 1) / (2 * n));

                    result[v, u] = U * V * temp / Math.Sqrt(2 * n);
                }
            }

            return result;
        }

        private static double[,] ODKP(double[,] dkp) {
            int n = dkp.GetLength(0);
            var result = new double[n, n];
            for (var v = 0; v < n; v++) {
                for (var u = 0; u < n; u++) {
                    double temp = 0;
                    for (var i = 0; i < n; i++) {
                        for (var j = 0; j < n; j++) {
                            double V;
                            if (i == 0)
                                V = 1.0 / Math.Sqrt(2);
                            else
                                V = 1;

                            double U;
                            if (j == 0)
                                U = 1.0 / Math.Sqrt(2);
                            else
                                U = 1;

                            temp += U * V * dkp[i, j] * Math.Cos(Math.PI * i * (2 * v + 1) / (2 * n)) * Math.Cos(Math.PI * j * (2 * u + 1) / (2 * n));
                        }
                    }

                    result[v, u] = temp / Math.Sqrt(2 * n);
                }
            }

            return result;
        }

        private static double[,] Normalization(double[,] odkp) {
            double min = double.MaxValue, max = double.MinValue;
            for (var i = 0; i < odkp.GetLength(0); i++)
                for (var j = 0; j < odkp.GetLength(1); j++) {
                    if (odkp[i, j] > max)
                        max = odkp[i, j];
                    
                    if (odkp[i, j] < min)
                        min = odkp[i, j];
                }

            var result = new double[odkp.GetLength(0), odkp.GetLength(1)];
            for (var i = 0; i < odkp.GetLength(0); i++)
                for (var j = 0; j < odkp.GetLength(1); j++)
                    result[i, j] = 255 * (odkp[i, j] + Math.Abs(min)) / (max + Math.Abs(min));

            return result;
        }

        private void SendMessToForm(string mess) {
            if (form.InvokeRequired)
                form.Invoke((MethodInvoker)delegate { form.SendMessage(mess); });
            else
                form.SendMessage(mess);
        }


        private void BlockPanel(bool flag) {
            switch (flag) {
                case true when form.InvokeRequired:
                    form.Invoke((MethodInvoker)delegate { form.BlockPanel(); });
                    break;
                case true:
                    form.BlockPanel();
                    break;
                case false when form.InvokeRequired:
                    form.Invoke((MethodInvoker)delegate { form.UnblockPanel(); });
                    break;
                case false:
                    form.UnblockPanel();
                    break;
            }
        }
    }
}