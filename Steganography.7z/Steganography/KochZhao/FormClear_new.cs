﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Text;
using System.Threading;
using System.Windows.Forms;

using Steganography.Properties;

namespace Steganography {

    public partial class FormClear_new : Form {

        private Bitmap image1;
        private Bitmap image2;
        private KochClear_new koch;

        public FormClear_new() {
            InitializeComponent();
            image1 = new Bitmap(Resources.image);
            pictureBox1.Image = ResizeImage(image1, pictureBox1.Size);
            pictureBox1.Invalidate();
            koch = new KochClear_new(this);
        }

        private static Image ResizeImage(Image imgToResize, Size size) {
            int sourceWidth = imgToResize.Width;
            int sourceHeight = imgToResize.Height;
            float nPercentW = size.Width / (float)sourceWidth;
            float nPercentH = size.Height / (float)sourceHeight;
            float nPercent = nPercentH < nPercentW ? nPercentH : nPercentW;

            var destWidth = (int)(sourceWidth * nPercent);
            var destHeight = (int)(sourceHeight * nPercent);
            var b = new Bitmap(destWidth, destHeight);
            Graphics g = Graphics.FromImage(b);
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
            g.DrawImage(imgToResize, 0, 0, destWidth, destHeight);
            g.Dispose();
            return b;
        }

        private void pictureBox1_Click(object sender, EventArgs e) {
            var load = new OpenFileDialog();
            load.Multiselect = false;
            load.Filter = "Image Files(*.bmp;*.png)|*.bmp;*.png|All files (*.*)|*.*";
            if (load.ShowDialog() != DialogResult.OK)
                return;

            try {
                string filename = load.FileName;

                string ex = filename.Substring(filename.LastIndexOf(".", StringComparison.Ordinal) + 1);
                if (string.CompareOrdinal(ex, "bmp") != 0 && string.CompareOrdinal(ex, "png") != 0 && string.CompareOrdinal(ex, "Bmp") != 0 && string.CompareOrdinal(ex, "Png") != 0)
                    throw new Exception("Неподдерживаемый формат");
                
                image1 = new Bitmap(load.FileName);
                pictureBox1.Image = ResizeImage(image1, pictureBox1.Size);
                int imageX = pictureBox1.Image.Width;
                int imageY = pictureBox1.Image.Height;
                int panelX = panel1.Width;
                int panelY = panel1.Height;
                int dX = (panelX - imageX) / 2;
                int dY = (panelY - imageY) / 2;
                pictureBox1.Left = dX;
                pictureBox1.Top = dY;
                pictureBox1.Size = new Size(imageX, imageY);
                pictureBox1.Invalidate();
                Stream inputStream = File.OpenRead(filename);
                long size = inputStream.Length;
                inputStream.Close();

                label7.Text = "Размер контейнера: " + image1.Width + "x" + image1.Height + " (" + size + " байт)";
                koch.fileName = filename;
                koch.image1 = new Bitmap(image1);

                const int sizeSegment = 2;
                int maxSize;
                if (image1 != null) {
                    int countB = image1.Height / sizeSegment * (image1.Width / sizeSegment);
                    int max = countB / 8;
                    maxSize = max;
                } else {
                    maxSize = 0;
                }

                Console.WriteLine(maxSize);

                var rnd = new Random();
                var vals = new[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };

                var hide = "";

                for (var i = 0; i < maxSize / 2; i++) {
                    int val = vals[rnd.Next(vals.Length)];
                    hide += val.ToString();
                }

                const string path = @".\";
                File.WriteAllText(path + "\\BIN" + ".txt", Convert.ToString(hide), Encoding.Default);
                const string filename1 = @".\BIN.txt";

                Console.WriteLine(filename1);
                koch.LoadMessage(filename1);
                Update();
            } catch (Exception ex) {
                MessageBox.Show("Ошибка открытия файла\n" + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            } finally {
                pictureBox2.Image = null;
                pictureBox2.Size = panel2.Size;
                pictureBox2.Top = 0;
                pictureBox2.Left = 0;
            }
        }

        private new void Update() {
            if (progressBar1.Value > 99)
                progressBar1.Value = 0;

            if (koch.sizeSegment != 0 && koch.image1 != null) {
                int count = koch.image1.Height / koch.sizeSegment * (koch.image1.Width / koch.sizeSegment);
                label9.Text = "Количество блоков: " + count;
            } else {
                label9.Text = "Количество блоков: ";
            }

            if (koch.hideInf != null)
                label8.Text = "Размер сообщения: " + koch.hideInf.Length + " байт";
            else
                label8.Text = "Размер сообщения: ";

            MaxDataSize();
            if (koch.sizeSegment != 0 && koch.image1 != null)
                label10.Text = "Макс. объем встраиваемой инф.: " + koch.maxSize + " байт";
            else
                label10.Text = "Макс. объем встраиваемой инф.: ";

            if (koch.hideInf != null && koch.sizeSegment != 0 && koch.image1 != null)
                butInlining.Enabled = true;
            else
                butInlining.Enabled = false;

            GetKey();
            if (koch.sizeSegment != 0 && koch.image1 != null && koch.mKey != 0)
                butExtr.Enabled = true;
            else
                butExtr.Enabled = false;

            trackBar1.Value = koch.P;

            if (koch.hideInf == null)
                textBox1.Text = "";

            if (koch.image1 == null) {
                label7.Text = "Размер контейнера: ";
                label2.Text = "Исходное изображение ";
            }

            if (image2 == null)
                label1.Text = "После очистки ";
        }

        private void GetKey() {
            if (textBox2.Text.Length != 0)
                koch.mKey = Convert.ToInt32(textBox2.Text);
        }

        private void button3_Click(object sender, EventArgs e) {
            string filename = Resources.BIN;
            try {
                koch.LoadMessage(filename);
                Update();
            } catch (Exception ex) {
                MessageBox.Show("Ошибка открытия файла\n" + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button1_Click(object sender, EventArgs e) {
            textBox2.Text = Convert.ToString(koch.hideInf.Length);
            var InstanceCaller = new Thread(DoWork1);
            InstanceCaller.Start();
        }

        private void DoWork1() {
            koch.Inlining();
        }

        public void SendMessage(string mess) {
            richTextBox1.Text += mess + "\n";
            richTextBox1.SelectionStart = richTextBox1.Text.Length;
            richTextBox1.ScrollToCaret();
        }

        public void Picture2(Bitmap image) {
            image2 = image;
            pictureBox2.Size = panel2.Size;
            pictureBox2.Image = ResizeImage(image2, pictureBox2.Size);
            int imageX = pictureBox2.Image.Width;
            int imageY = pictureBox2.Image.Height;
            int panelX = panel2.Width;
            int panelY = panel2.Height;
            int dX = (panelX - imageX) / 2;
            int dY = (panelY - imageY) / 2;
            pictureBox2.Left = dX;
            pictureBox2.Top = dY;
            pictureBox2.Size = new Size(imageX, imageY);
            pictureBox2.Invalidate();
        }

        private void button2_Click(object sender, EventArgs e) {
            var InstanceCaller = new Thread(DoWork);
            InstanceCaller.Start();
        }

        private void DoWork() {
            koch.extraction();
        }

        public void BlockPanel() {
            panel3.Enabled = false;
        }

        public void UnblockPanel() {
            panel3.Enabled = true;
        }

        public void Progress(double val) {
            if (val > 100)
                progressBar1.Value = 100;
            else
                progressBar1.Value = (int)val;
        }

        private void MaxDataSize() {
            koch.maxMessSize();
            if (koch.hideInf == null)
                return;

            if (koch.maxSize > 0 && koch.hideInf.Length > 0 && koch.hideInf.Length <= koch.maxSize) { }
        }

        private void button2_Click_1(object sender, EventArgs e) {
            if (image1 != null) {
                image1.Dispose();
                image1 = null;
            }

            if (image2 != null) {
                image2.Dispose();
                image2 = null;
            }

            koch.image1?.Dispose();

            koch = new KochClear_new(this);
            pictureBox2.Image = null;
            pictureBox2.Size = panel2.Size;
            pictureBox2.Top = 0;
            pictureBox2.Left = 0;
            pictureBox1.Size = panel1.Size;
            pictureBox1.Top = 0;
            pictureBox1.Left = 0;
            image1 = new Bitmap("Res//image.png");
            pictureBox1.Image = ResizeImage(image1, pictureBox1.Size);
            pictureBox1.Invalidate();

            textBox2.Text = "";
            label10.Text = "Макс. объем встраиваемой инф.:";
            label9.Text = "Количество блоков: ";
            label8.Text = "Размер сообщения: ";
            label7.Text = "Размер контейнера: ";
            textBox1.Text = "";
            label5.Text = "Размер блоков";
            label4.Text = "25";
            trackBar1.Value = 25;
            butExtr.Enabled = false;
            butInlining.Enabled = false;
            richTextBox1.Text = "";
            label1.Text = "После очистки";
            label2.Text = "Исходное изображение ";
            progressBar1.Value = 0;
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e) {
            if (e.KeyChar >= 47 && e.KeyChar <= 58) {
                textBox2.Text += e.KeyChar;
                e.Handled = true;
            } else if (e.KeyChar == 8 && textBox2.Text.Length > 0) {
                textBox2.Text = textBox2.Text.Substring(0, textBox2.Text.Length - 1);
                if (textBox2.Text.Length > 0) {
                    var m = Convert.ToInt32(textBox2.Text);
                    koch.mKey = m;
                } else {
                    koch.mKey = 0;
                }

                e.Handled = true;
            } else {
                e.Handled = true;
            }

            Update();
            textBox2.Select(textBox2.Text.Length, textBox2.Text.Length);
        }


        private void TrackBar1_ValueChanged(object sender, EventArgs e) {
            try {
                label4.Text = trackBar1.Value.ToString();
                koch.P = trackBar1.Value;
            } catch (Exception) {
                koch.P = 25;
                label4.Text = "25";
                trackBar1.Value = 25;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e) {
            try {
                string filename = textBox1.Text;
                FileStream fs = File.Open(filename, FileMode.Open, FileAccess.Read, FileShare.None);
                fs.Close();
                koch.LoadMessage(filename);
            } catch (Exception) {
                label8.Text = "Размер сообщения: файл не найден";
                koch.hideInf = null;
                butInlining.Enabled = false;
            }

            Update();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e) {
            var comboBox = (ComboBox)sender;
            var selectedEmployee = (string)comboBox.SelectedItem;
            koch.sizeSegment = selectedEmployee switch {
                "2x2" => 2,
                "4x4" => 4,
                "8x8" => 8,
                _ => koch.sizeSegment
            };

            Update();
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e) {
            Form mainForm = new MainForm();
            mainForm.Show();
            Dispose();
        }
    }
}