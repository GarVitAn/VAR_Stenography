﻿using System;
using System.IO;
using System.Windows.Forms;

namespace Steganography {

    public partial class MainForm : Form {

        public MainForm() {
            InitializeComponent();

            var t = new ToolTip();
            t.SetToolTip(button1, "Кодирование информации \nв изображение");
            t.SetToolTip(button2, "Декодирование информации \nиз изображения");
            t.SetToolTip(button3, "Сравнение изображений");
            t.SetToolTip(button4, "Очистка изображения путем кодирования \nслучайной информации в изображение");

            const string subPath1 = "Кодирование";
            bool exists1 = Directory.Exists(subPath1);
            if (!exists1)
                Directory.CreateDirectory(subPath1);

            const string subPath2 = "Декодирование";
            bool exists2 = Directory.Exists(subPath2);
            if (!exists2)
                Directory.CreateDirectory(subPath2);

            const string subPath3 = "Сравнение изображений";
            bool exists3 = Directory.Exists(subPath3);
            if (!exists3)
                Directory.CreateDirectory(subPath3);

            const string subPath4 = "Очистка изображений";
            bool exists4 = Directory.Exists(subPath4);
            if (!exists4)
                Directory.CreateDirectory(subPath4);
        }

        private void OpenEncoding_Click(object sender, EventArgs e) {
            Form form = new EncodingForm();
            form.Show();
            Hide();
        }

        private void Exit_Click(object sender, FormClosedEventArgs e) {
            Application.Exit();
        }

        private void OpenDecoding_Click(object sender, EventArgs e) {
            Form form = new DecodingForm();
            form.Show();
            Hide();
        }

        private void OpenComparison_Click(object sender, EventArgs e) {
            Form form = new ComparisonForm();
            form.Show();
            Hide();
        }

        private void OpenClear_Click(object sender, EventArgs e) {
            Form form = new FormClear_new();
            form.Show();
            Hide();
        }
    }
}