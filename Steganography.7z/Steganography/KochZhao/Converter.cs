﻿using System;
using System.Collections;
using System.Linq;

namespace Steganography {

    internal class Converter {

        public readonly ArrayList bits = new ArrayList();
        private readonly int _value;

        public Converter(int value) {
            _value = value;
            IntToBits();
        }

        private void IntToBits() {
            int temp = _value;
            for (var i = 0; i < 8; i++) {
                bits.Add(temp % 2);
                temp = (int)Math.Floor((double)temp / 2);
            }

            bits.Reverse();
        }

        public override string ToString() {
            return bits.Cast<object>().Aggregate("", (current, t) => current + t);
        }
    }
}
