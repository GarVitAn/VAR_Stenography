﻿using System;
using System.Threading;
using System.Windows.Forms;

namespace Steganography {

    internal static class Program {
        [STAThread]
        [Obsolete("Obsolete")]
        private static void Main() {
            Application.ThreadException += Application_ThreadException;

            AppDomain.CurrentDomain.UnhandledException += CurrentDomain_UnhandledException;

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            Application.Run(new MainForm());

            Environment.Exit(-1);
        }

        private static void Application_ThreadException(object sender, ThreadExceptionEventArgs e) {
            ShowExceptionDetails(e.Exception);
        }

        [Obsolete("Obsolete")]
        private static void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e) {
            ShowExceptionDetails(e.ExceptionObject as Exception);

            Thread.CurrentThread.Suspend();
        }

        private static void ShowExceptionDetails(Exception Ex) {
            MessageBox.Show(Ex.Message, Ex.TargetSite.ToString(), MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}