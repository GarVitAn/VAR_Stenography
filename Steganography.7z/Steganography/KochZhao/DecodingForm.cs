﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Threading;
using System.Windows.Forms;

using Steganography.Properties;

using static System.String;

namespace Steganography {

    public partial class DecodingForm : Form {

        private Bitmap image1;

        private readonly Koch3 koch;

        public DecodingForm() {
            InitializeComponent();
            image1 = new Bitmap(Resources.image);
            pictureBox1.Image = ResizeImage(image1, pictureBox1.Size);
            pictureBox1.Invalidate();
            koch = new Koch3(this);
        }

        private static Image ResizeImage(Image imgToResize, Size size) {
            int sourceWidth = imgToResize.Width;
            int sourceHeight = imgToResize.Height;
            float nPercentW = size.Width / (float)sourceWidth;
            float nPercentH = size.Height / (float)sourceHeight;
            float nPercent = nPercentH < nPercentW ? nPercentH : nPercentW;

            var destWidth = (int)(sourceWidth * nPercent);
            var destHeight = (int)(sourceHeight * nPercent);
            var b = new Bitmap(destWidth, destHeight);
            Graphics g = Graphics.FromImage(b);
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
            g.DrawImage(imgToResize, 0, 0, destWidth, destHeight);
            g.Dispose();
            return b;
        }

        private void pictureBox1_Click(object sender, EventArgs e) {
            var load = new OpenFileDialog();
            load.Multiselect = false;
            load.Filter = "Image Files(*.bmp;*.png)|*.bmp;*.png|All files (*.*)|*.*";
            if (load.ShowDialog() != DialogResult.OK)
                return;

            try {
                string filename = load.FileName;
                string ex = filename.Substring(filename.LastIndexOf(".", StringComparison.Ordinal) + 1);
                if (CompareOrdinal(ex, "bmp") != 0 && CompareOrdinal(ex, "png") != 0 && Compare(ex, "jpg") != 0 && Compare(ex, "Bmp") != 0 && Compare(ex, "Png") != 0)
                    throw new Exception("Неподдерживаемый формат");

                image1 = new Bitmap(load.FileName);
                pictureBox1.Image = ResizeImage(image1, pictureBox1.Size);
                int imageX = pictureBox1.Image.Width;
                int imageY = pictureBox1.Image.Height;
                int panelX = panel1.Width;
                int panelY = panel1.Height;
                int dX = (panelX - imageX) / 2;
                int dY = (panelY - imageY) / 2;
                pictureBox1.Left = dX;
                pictureBox1.Top = dY;
                pictureBox1.Size = new Size(imageX, imageY);
                pictureBox1.Invalidate();
                Stream inputStream = File.OpenRead(filename);
                inputStream.Close();

                koch.filename = filename;
                koch.image1 = new Bitmap(image1);
                Update();
            } catch (Exception ex) {
                MessageBox.Show("Ошибка открытия файла\n" + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void GetKey() {
            if (textBox2.Text.Length != 0)
                koch.mKey = Convert.ToInt32(textBox2.Text);
        }

        public void SendMessage(string mess) {
            richTextBox1.Text += mess + "\n";
            richTextBox1.SelectionStart = richTextBox1.Text.Length;
            richTextBox1.ScrollToCaret();
        }

        private void button2_Click(object sender, EventArgs e) {
            string[] ss = Array.Empty<string>();
            richTextBox1.Lines = ss;
            var InstanceCaller = new Thread(DoWork);
            InstanceCaller.Start();
        }

        private void DoWork() {
            koch.Extraction();
        }

        public void BlockPanel() {
            panel3.Enabled = false;
        }

        public void UnblockPanel() {
            panel3.Enabled = true;
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e) {
            if (e.KeyChar >= 47 && e.KeyChar <= 58) {
                textBox2.Text += e.KeyChar;
                e.Handled = true;
            } else if (e.KeyChar == 8 && textBox2.Text.Length > 0) {
                textBox2.Text = textBox2.Text.Substring(0, textBox2.Text.Length - 1);
                if (textBox2.Text.Length > 0) {
                    var m = Convert.ToInt32(textBox2.Text);
                    koch.mKey = m;
                } else {
                    koch.mKey = 0;
                }

                e.Handled = true;
            } else {
                e.Handled = true;
            }

            textBox2.Select(textBox2.Text.Length, textBox2.Text.Length);
            Update();
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e) {
            Form mainForm = new MainForm();
            mainForm.Show();
            Dispose();
        }

        private new void Update() {
            GetKey();
            if (koch.sizeSegment != 0 && koch.image1 != null && koch.mKey != 0)
                butExtr.Enabled = true;
            else
                butExtr.Enabled = false;
            
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e) {
            var comboBox = (ComboBox)sender;
            var selectedEmployee = (string)comboBox.SelectedItem;
            koch.sizeSegment = selectedEmployee switch {
                "2x2" => 2,
                "4x4" => 4,
                "8x8" => 8,
                _ => koch.sizeSegment
            };

            Update();
        }
    }
}