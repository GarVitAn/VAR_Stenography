﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Forms;

using Steganography.Properties;

namespace Steganography {

    public partial class ComparisonForm : Form {

        private Bitmap image1;
        private Bitmap image2;
        private readonly ComparisonForm form = null;

        private ImageFormat imageFormat1;
        private ImageFormat imageFormat2;

        private string filename1;
        private string filename2;

        public ComparisonForm() {
            InitializeComponent();
            image1 = new Bitmap(Resources.image);
            pictureBox1.Image = ResizeImage(image1, panel1.Size);
            pictureBox1.Invalidate();
            image2 = new Bitmap(Resources.image);
            pictureBox2.Image = ResizeImage(image2, panel2.Size);
            pictureBox2.Invalidate();
        }

        private static Image ResizeImage(Image imgToResize, Size size) {
            int sourceWidth = imgToResize.Width;
            int sourceHeight = imgToResize.Height;
            float nPercentW = size.Width / (float)sourceWidth;
            float nPercentH = size.Height / (float)sourceHeight;
            float nPercent = nPercentH < nPercentW ? nPercentH : nPercentW;

            var destWidth = (int)(sourceWidth * nPercent);
            var destHeight = (int)(sourceHeight * nPercent);
            var b = new Bitmap(destWidth, destHeight);
            Graphics g = Graphics.FromImage(b);
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
            g.DrawImage(imgToResize, 0, 0, destWidth, destHeight);
            g.Dispose();
            return b;
        }

        private void pictureBox1_Click(object sender, EventArgs e) {
            pictureBox3.Image = null;

            var load = new OpenFileDialog();
            load.Multiselect = false;
            load.Filter = "Image Files(*.bmp;*.png)|*.bmp;*.png|All files (*.*)|*.*";
            if (load.ShowDialog() != DialogResult.OK) 
                return;
            
            try {
                string filename = load.FileName;
                filename1 = filename;
                string ex = filename.Substring(filename.LastIndexOf(".", StringComparison.Ordinal) + 1);
                if (string.CompareOrdinal(ex, "bmp") != 0 && string.CompareOrdinal(ex, "png") != 0 && string.CompareOrdinal(ex, "Bmp") != 0 && string.CompareOrdinal(ex, "Png") != 0)
                    throw new Exception("Неподдерживаемый формат");
                

                image1 = new Bitmap(load.FileName);
                pictureBox1.Image = image1;

                imageFormat1 = ex switch {
                    "bmp" => ImageFormat.Bmp,
                    "png" => ImageFormat.Png,
                    "Bmp" => ImageFormat.Bmp,
                    "Png" => ImageFormat.Png,
                    _ => imageFormat1
                };
                
                pictureBox1.Invalidate();
                Stream inputStream = File.OpenRead(filename);
                inputStream.Close();

                Update();
            } catch (Exception ex) {
                MessageBox.Show("Ошибка открытия файла\n" + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                form.Dispose();
            }
        }

        private void pictureBox2_Click_1(object sender, EventArgs e) {
            pictureBox3.Image = null;

            var load = new OpenFileDialog();
            load.Multiselect = false;
            load.Filter = "Image Files(*.bmp;*.png)|*.bmp;*.png|All files (*.*)|*.*";
            if (load.ShowDialog() != DialogResult.OK)
                return;

            try {
                string filename = load.FileName;
                filename2 = filename;
                string ex = filename.Substring(filename.LastIndexOf(".", StringComparison.Ordinal) + 1);
                if (string.CompareOrdinal(ex, "bmp") != 0 && string.CompareOrdinal(ex, "png") != 0 && string.CompareOrdinal(ex, "Bmp") != 0 && string.CompareOrdinal(ex, "Png") != 0)
                    throw new Exception("Неподдерживаемый формат");

                imageFormat2 = ex switch {
                    "bmp" => ImageFormat.Bmp,
                    "png" => ImageFormat.Png,
                    "Bmp" => ImageFormat.Bmp,
                    "Png" => ImageFormat.Png,
                    _ => imageFormat2
                };

                image2 = new Bitmap(load.FileName);
                pictureBox2.Image = image2;
                pictureBox2.Invalidate();
                Stream inputStream = File.OpenRead(filename);
                inputStream.Close();

                Update();
            } catch (Exception ex) {
                MessageBox.Show("Ошибка открытия файла\n" + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private new void Update() {
            if (progressBar1.Value > 99)
                progressBar1.Value = 0;

            if (image1 != null && image2 != null)
                butCompare.Enabled = true;
        }

        private void button1_Click(object sender, EventArgs e) {
            Invoke(new Action(() => {
                ControlBox = false;
                butCompare.Enabled = false;
                progressBar1.Value = 0;
                richTextBox1.Clear();
            }));
            try {
                SendMessage("Сравнение изображений началось...");
                SendMessage("Результат процесса сравнения изображений будет показан на изображении №3.");
                Color.FromName("Black");
                Color.FromName("White");

                if (image1.Width == image2.Width &&
                    image1.Height == image2.Height) {
                    SendMessage("Ширина у изображений равная.");
                    SendMessage("Высота у изображений равная.");

                    Invoke(new Action(() => {
                        pictureBox3.Invalidate();
                        pictureBox3.Image = null;
                    }));

                    var bitmap = new Bitmap(pictureBox1.Image.Width, pictureBox1.Image.Height);
                    int temp = image1.Height * image1.Width / 10;


                    for (var i = 0; i < image1.Height; i++)
                        for (var j = 0; j < image1.Width; j++) {
                            if (i * j >= temp) {
                                Invoke(new Action(() => { progressBar1.PerformStep(); }));
                                temp += temp;
                            }

                            int j1 = j;
                            int i1 = i;
                            Invoke(new Action(() => { bitmap.SetPixel(j1, i1, image1.GetPixel(j1, i1) == image2.GetPixel(j1, i1) ? Color.Black : Color.White); }));
                        }
                    
                    var time = DateTime.Now.ToString("dd.MM.yyyy");
                    var time1 = DateTime.Now.ToString("HH.mm.ss");

                    string path = @"Сравнение изображений\" + time + "_" + time1;
                    bool exists1 = Directory.Exists(path);
                    if (!exists1)
                        Directory.CreateDirectory(path);

                    string path1 = path + "\\Изображение1_." + Path.GetFileName(filename1);
                    image1.Save(path1, imageFormat1);
                    string path2 = path + "\\Изображение2_." + Path.GetFileName(filename2);
                    image2.Save(path2, imageFormat2);

                    Invoke(new Action(() => {
                        pictureBox3.Image = bitmap;
                        pictureBox3.Refresh();
                    }));
                    
                    string path3 = path + "\\Изображение3_." + Path.GetFileName(filename2);
                    bitmap.Save(path3, ImageFormat.Png);
                } else {
                    SendMessage("Ширина и(или) высота изображений не равны.");
                }

                Invoke(new Action(() => {
                    ControlBox = true;
                    butCompare.Enabled = true;
                }));
            } catch (Exception ex) {
                MessageBox.Show("Ошибка\n" + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void SendMessage(string mess) {
            Invoke(new Action(() => {
                richTextBox1.Text += mess + "\n";
                richTextBox1.SelectionStart = richTextBox1.Text.Length;
                richTextBox1.ScrollToCaret();
            }));
        }
        
        private void Form1_FormClosed(object sender, FormClosedEventArgs e) {
            Form mainForm = new MainForm();
            mainForm.Show();
            Dispose();
        }
    }
}