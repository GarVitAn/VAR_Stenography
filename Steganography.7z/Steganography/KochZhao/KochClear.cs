﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Steganography {

    public class KochClear {

        private readonly FormClear form;

        public byte[] hideInf;
        public int P = 25;
        public int mKey = 0;
        public int sizeSegment = 2;
        public string filename = "";
        public Bitmap image1 = null;

        private Point p1;
        private Point p2;

        private ImageFormat imageFormat;
        public int maxSize;

        public KochClear(FormClear form) {
            this.form = form;
        }

        public void InLining() {
            try {
                var workImage = new Bitmap(image1);
                ChangeProgress(0);
                BlockPanel(true);
                SendMessToForm("Начало встраивания");
                InitialPoint();
                string ex = filename.Substring(filename.LastIndexOf(".", StringComparison.Ordinal) + 1);
                SendMessToForm("Расширение контейнера: " + ex);
                SendMessToForm("P = " + P);
                SendMessToForm("Размер блоков = " + sizeSegment);
                SendMessToForm("Точки встраивания: (" + p1.X + "; " + p1.Y + ")  (" + p2.X + "; " + p2.Y + ")");
                SendMessToForm("Ключ для извлечения: " + hideInf.Length);

                imageFormat = ex switch {
                    "bmp" => ImageFormat.Bmp,
                    "png" => ImageFormat.Png,
                    _ => imageFormat
                };

                if (workImage.Width % sizeSegment != 0 || workImage.Height % sizeSegment != 0) {
                    Trim(ref workImage, sizeSegment);
                }

                int sizeX = workImage.Width;
                int sizeY = workImage.Height;
                var R = new byte[sizeX, sizeY];
                var G = new byte[sizeX, sizeY];
                var B = new byte[sizeX, sizeY];
                for (var i = 0; i < sizeX; i++) {
                    for (var j = 0; j < sizeY; j++) {
                        R[i, j] = workImage.GetPixel(i, j).R;
                        G[i, j] = workImage.GetPixel(i, j).G;
                        B[i, j] = workImage.GetPixel(i, j).B;
                    }
                }

                ChangeProgress(5);
                var sepB = new List<byte[,]>();
                Separation(B, ref sepB, sizeX, sizeY, sizeSegment);
                SendMessToForm("Вычисление ДКП");
                List<double[,]> DKP = sepB.Select(KochClear.DKP).ToList();
                ChangeProgress(15);
                SendMessToForm("Встраивание информации");
                InLiningMess(hideInf, ref DKP, P, p1, p2);
                ChangeProgress(65);
                SendMessToForm("Вычисление ОДКП");
                List<double[,]> ODKP = DKP.Select(KochClear.ODKP).ToList();
                ChangeProgress(75);
                var newB = new double[sizeX, sizeY];
                Integration(ODKP, ref newB, sizeX, sizeY, sizeSegment);
                newB = Normalization(newB);
                ChangeProgress(85);
                for (var i = 0; i < sizeX; i++)
                for (var j = 0; j < sizeY; j++) {
                    workImage.SetPixel(i, j, Color.FromArgb(R[i, j], G[i, j], (byte)Math.Round(newB[i, j])));
                }

                ChangeProgress(95);
                SendMessToForm("Встраивание завершено!");
                SendPicture(workImage);
                string name = filename.Substring(filename.LastIndexOf("\\", StringComparison.Ordinal) + 1);
                string path = Path.GetDirectoryName(filename);
                File.WriteAllText(path + "\\Зашифрованная_картинка-" + name + ".key.txt", Convert.ToString(hideInf.Length), Encoding.Default);
                path += "\\Зашифрованная_картинка-" + name;
                workImage.Save(path, imageFormat);
                ChangeProgress(100);
                SendMessToForm("Сохранено: " + path + "\n\n");
            } catch (Exception e) {
                ChangeProgress(100);
                SendMessToForm("Ошибка встраивания: " + e.Message + "\n\n");
            } finally {
                BlockPanel(false);
            }
        }

        public void extraction() {
            try {
                ChangeProgress(0);
                BlockPanel(true);
                SendMessToForm("Начало извлечения");
                InitialPoint();
                SendMessToForm("P = " + P);
                SendMessToForm("размер блоков = " + sizeSegment);
                SendMessToForm("точки встраивания: (" + p1.X + "; " + p1.Y + ")  (" + p2.X + "; " + p2.Y + ")");
                SendMessToForm("Ключ: " + mKey);

                var image = (Bitmap)Image.FromFile(filename);
                int sizeX = image.Width;
                int sizeY = image.Height;
                var R = new byte[sizeX, sizeY];
                var G = new byte[sizeX, sizeY];
                var B = new byte[sizeX, sizeY];
                for (var i = 0; i < sizeX; i++)
                for (var j = 0; j < sizeY; j++) {
                    R[i, j] = image.GetPixel(i, j).R;
                    G[i, j] = image.GetPixel(i, j).G;
                    B[i, j] = image.GetPixel(i, j).B;
                }

                ChangeProgress(5);
                var sepB = new List<byte[,]>();
                Separation(B, ref sepB, sizeX, sizeY, sizeSegment);
                SendMessToForm("Вычисление ДКП");
                ChangeProgress(10);
                List<double[,]> DKP = sepB.Select(KochClear.DKP).ToList();
                ChangeProgress(20);
                SendMessToForm("Извлечение информации");
                int size = mKey;
                var stringBits = "";
                var message = new List<byte>();
                int key = mKey;
                var allPos = new List<int>();
                for (var i = 0; i < DKP.Count; i++) {
                    allPos.Add(i);
                }

                ChangeProgress(30);
                double incr = 50 / size;
                double prgb = 30;
                while (size > 0) {
                    key = MultiTransfer(key, allPos.Count);
                    int pos = allPos[key];
                    allPos.RemoveAt(key);
                    double AbsPoint1 = Math.Abs(DKP[pos][p1.X, p1.Y]);
                    double AbsPoint2 = Math.Abs(DKP[pos][p2.X, p2.Y]);
                    if (AbsPoint1 > AbsPoint2) {
                        stringBits += "0";
                    }

                    if (AbsPoint1 < AbsPoint2) {
                        stringBits += "1";
                    }

                    if (stringBits.Length != 8) {
                        continue;
                    }

                    message.Add(Convert.ToByte(Convert.ToInt32(stringBits, 2)));
                    stringBits = "";
                    size--;
                    prgb += incr;
                    ChangeProgress(prgb);
                }

                ChangeProgress(80);
                image.Dispose();
                string[] ex = Processing(message);
                ChangeProgress(90);
                var message2 = new List<byte>();
                for (int i = ex[0].Length + 1; i < message.Count - ex[0].Length - 1; i++) {
                    message2.Add(message[i]);
                }

                ChangeProgress(95);
                SendMessToForm("Извлечение завершено!");
                SendMessToForm("Извлечено " + message2.Count + " байт");
                string path = Path.GetDirectoryName(filename);
                path += "\\mess." + ex[0];
                if (SaveMessage(message2, path)) {
                    SendMessToForm("Сохранено: " + path);
                }

                if (string.Compare(ex[0], ex[1], StringComparison.Ordinal) != 0) {
                    var message3 = new List<byte>();
                    for (int i = ex[1].Length + 1; i < message.Count - ex[1].Length - 1; i++) {
                        message3.Add(message[i]);
                    }

                    string path2 = Path.GetDirectoryName(filename);
                    path2 += "\\mess2." + ex[1];
                    if (SaveMessage(message3, path2)) {
                        SendMessToForm("Сохранено (попытка 2): " + path2);
                    }

                    var message4 = new List<byte>();
                    for (int i = 4 + 1; i < message.Count - 4; i++) {
                        message4.Add(message[i]);
                    }

                    string path3 = Path.GetDirectoryName(filename);
                    path3 += "\\mess3";
                    if (SaveMessage(message4, path3)) {
                        SendMessToForm("Сохранено (попытка 3): " + path3);
                    }
                }

                SendMessToForm("\n\n");
                ChangeProgress(100);
            } catch (Exception) {
                ChangeProgress(100);
                SendMessToForm("Не удалось извлечь сообщение!\n\n");
            } finally {
                BlockPanel(false);
            }
        }

        private bool SaveMessage(List<byte> message, string path) {
            try {
                File.WriteAllBytes(path, message.ToArray());
                return true;
            } catch (Exception) {
                SendMessToForm("Не удалось извлечь сообщение!\n\n");
                return false;
            }
        }

        private static string[] Processing(IReadOnlyList<byte> message) {
            var ex = new string[2];
            string tmp = message.Select(Convert.ToInt32).TakeWhile(n => n != 126).Aggregate("", (current, n) => current + Convert.ToChar(n));
            var tmp2 = "";
            for (int i = message.Count - 1; i >= 0; i--) {
                var n = Convert.ToInt32(message[i]);
                if (n == 126)
                    break;

                tmp2 += Convert.ToChar(n);
            }

            var tmp3 = "";
            for (int i = tmp2.Length - 1; i >= 0; i--)
                tmp3 += tmp2[i];
            
            if (tmp.Length < 10)
                ex[0] = tmp;
            else 
                ex[0] = tmp.Substring(0, 9);
            
            if (tmp3.Length < 10)
                ex[1] = tmp3;
            else
                ex[1] = tmp3.Substring(0, 9);
            

            return ex;
        }

        public void MaxMessSize() {
            if (image1 != null && sizeSegment > 0) {
                int countB = image1.Height / sizeSegment * (image1.Width / sizeSegment);
                int max = countB / 8;
                maxSize = max;
            } else {
                maxSize = 0;
            }
        }

        private static void Trim(ref Bitmap image, int sizeSegment) {
            int x = image.Width % sizeSegment;
            int y = image.Height % sizeSegment;
            var newSize = new Size(image.Width - x, image.Height - y);
            var b = new Bitmap(newSize.Width, newSize.Height);
            for (var i = 0; i < b.Width; i++)
            for (var j = 0; j < b.Height; j++)
                b.SetPixel(i, j, image.GetPixel(i, j));

            image = b;
        }

        private void InLiningMess(IReadOnlyCollection<byte> message, ref List<double[,]> DKP, int P, Point point1, Point point2) {
            int key = message.Count;
            var allPos = new List<int>();
            for (var i = 0; i < DKP.Count; i++)
                allPos.Add(i);

            ChangeProgress(20);
            double incr = 45 / message.Count;
            double pgrb = 20;
            foreach (byte t in message) {
                var conv = new Converter(t);
                for (var j = 0; j < 8; j++) {
                    key = MultiTransfer(key, allPos.Count);
                    int pos = allPos[key];
                    allPos.RemoveAt(key);
                    double AbsPoint1 = Math.Abs(DKP[pos][point1.X, point1.Y]);
                    double AbsPoint2 = Math.Abs(DKP[pos][point2.X, point2.Y]);
                    int z1 = 1, z2 = 1;
                    if (DKP[pos][point1.X, point1.Y] < 0)
                        z1 = -1;

                    if (DKP[pos][point2.X, point2.Y] < 0)
                        z2 = -1;

                    if ((int)conv.bits[j] == 0)
                        if (AbsPoint1 - AbsPoint2 <= P)
                            AbsPoint1 = P + AbsPoint2 + 1;

                    if ((int)conv.bits[j] == 1)
                        if (AbsPoint1 - AbsPoint2 >= -P)
                            AbsPoint2 = P + AbsPoint1 + 1;

                    DKP[pos][point1.X, point1.Y] = z1 * AbsPoint1;
                    DKP[pos][point2.X, point2.Y] = z2 * AbsPoint2;
                }

                pgrb += incr;
                ChangeProgress(pgrb);
            }
        }

        private static int MultiTransfer(long x, int maxSize) {
            const long a = 0xffffda61L;
            x = a * (x & 65535) + (x >> 16);
            x = Math.Abs((int)x);
            if (x >= maxSize)
                x %= maxSize;

            return (int)x;
        }

        private void Separation(byte[,] B, ref List<byte[,]> C, int sizeX, int sizeY, int sizeSegment) {
            int Nx = sizeX / sizeSegment;
            int Ny = sizeY / sizeSegment;
            for (var i = 0; i < Nx; i++) {
                int startX = i * sizeSegment;
                int endX = startX + sizeSegment - 1;
                for (var j = 0; j < Ny; j++) {
                    int startY = j * sizeSegment;
                    int endY = startY + sizeSegment - 1;
                    C.Add(SubMatrix(B, startX, endX, startY, endY));
                }
            }
        }

        private static byte[,] SubMatrix(byte[,] B, int startX, int endX, int startY, int endY) {
            int Nx = endX - startX + 1;
            int Ny = endY - startY + 1;
            var res = new byte[Ny, Nx];
            for (var i = 0; i < Nx; i++) 
                for (var j = 0; j < Ny; j++) 
                    res[i, j] = B[i + startX, j + startY];

            return res;
        }

        private static void Insert(ref double[,] newB, double[,] tmp, int startX, int endX, int startY, int endY) {
            var u = 0;
            for (int i = startX; i < endX + 1; i++) {
                var v = 0;
                for (int j = startY; j < endY + 1; j++) {
                    newB[i, j] = tmp[u, v];
                    v++;
                }

                u++;
            }
        }

        private static void Integration(List<double[,]> ODKP, ref double[,] newB, int sizeX, int sizeY, int sizeSegment) {
            double[][,] tmp = ODKP.ToArray();
            int Nx = sizeX / sizeSegment;
            int Ny = sizeY / sizeSegment;
            var k = 0;
            for (var i = 0; i < Nx; i++) {
                int startX = i * sizeSegment;
                int endX = startX + sizeSegment - 1;
                for (var j = 0; j < Ny; j++) {
                    int startY = j * sizeSegment;
                    int endY = startY + sizeSegment - 1;
                    if (k > tmp.GetLength(0))
                        throw new IndexOutOfRangeException();

                    Insert(ref newB, tmp[k], startX, endX, startY, endY);
                    k++;
                }
            }
        }

        public void LoadMessage(string filename) {
            FileStream fs = File.Open(filename, FileMode.Open, FileAccess.Read);
            var ls = new List<byte>();
            while (true) {
                int b1 = fs.ReadByte();
                if (b1 == -1)
                    break;

                ls.Add((byte)b1);
            }

            string ex = filename.Substring(filename.LastIndexOf(".", StringComparison.Ordinal) + 1);
            string startStr = ex + "~";
            string endStr = "~" + ex;
            byte[] tmp = Encoding.GetEncoding(1251).GetBytes(startStr);
            var ls2 = new List<byte>();
            ls2.AddRange(tmp);
            ls2.AddRange(ls);
            tmp = Encoding.GetEncoding(1251).GetBytes(endStr);
            ls2.AddRange(tmp);
            hideInf = ls2.ToArray();
            fs.Close();
        }

        private void InitialPoint() {
            switch (sizeSegment) {
                case 2:
                    p1 = new Point(1, 0);
                    p2 = new Point(1, 1);
                    break;
                case 4:
                    p1 = new Point(3, 2);
                    p2 = new Point(2, 3);
                    break;
                case 8:
                    p1 = new Point(6, 3);
                    p2 = new Point(3, 6);
                    break;
            }
        }

        private static double[,] DKP(byte[,] C) {
            int n = C.GetLength(0);
            var result = new double[n, n];
            for (var v = 0; v < n; v++) {
                for (var u = 0; u < n; u++) {
                    double V;
                    if (v == 0)
                        V = 1.0 / Math.Sqrt(2);
                    else 
                        V = 1;
                    
                    double U;
                    if (u == 0)
                        U = 1.0 / Math.Sqrt(2);
                    else 
                        U = 1;
                    
                    double temp = 0;
                    for (var i = 0; i < n; i++) 
                        for (var j = 0; j < n; j++) {
                            temp += C[i, j] * Math.Cos(Math.PI * v * (2 * i + 1) / (2 * n)) * Math.Cos(Math.PI * u * (2 * j + 1) / (2 * n));
                        }

                    result[v, u] = U * V * temp / Math.Sqrt(2 * n);
                }
            }

            return result;
        }

        private static double[,] ODKP(double[,] dkp) {
            int n = dkp.GetLength(0);
            var result = new double[n, n];
            for (var v = 0; v < n; v++) {
                for (var u = 0; u < n; u++) {
                    double temp = 0;
                    for (var i = 0; i < n; i++) {
                        for (var j = 0; j < n; j++) {
                            double V;
                            if (i == 0)
                                V = 1.0 / Math.Sqrt(2);
                            else 
                                V = 1;
                            
                            double U;
                            if (j == 0)
                                U = 1.0 / Math.Sqrt(2);
                            else
                                U = 1;

                            temp += U * V * dkp[i, j] * Math.Cos(Math.PI * i * (2 * v + 1) / (2 * n)) * Math.Cos(Math.PI * j * (2 * u + 1) / (2 * n));
                        }
                    }

                    result[v, u] = temp / Math.Sqrt(2 * n);
                }
            }

            return result;
        }

        private static double[,] Normalization(double[,] odkp) {
            double min = double.MaxValue, max = double.MinValue;
            for (var i = 0; i < odkp.GetLength(0); i++)
                for (var j = 0; j < odkp.GetLength(1); j++) {
                    if (odkp[i, j] > max)
                        max = odkp[i, j];
                    
                    if (odkp[i, j] < min) 
                        min = odkp[i, j];
                }

            var result = new double[odkp.GetLength(0), odkp.GetLength(1)];
            for (var i = 0; i < odkp.GetLength(0); i++)
                for (var j = 0; j < odkp.GetLength(1); j++)
                    result[i, j] = 255 * (odkp[i, j] + Math.Abs(min)) / (max + Math.Abs(min));

            return result;
        }

        private void SendMessToForm(string mess) {
            if (form.InvokeRequired)
                form.Invoke((MethodInvoker)delegate { form.SendMessage(mess); });
            else
                form.SendMessage(mess);
        }

        private void SendPicture(Bitmap image) {
            if (form.InvokeRequired)
                form.Invoke((MethodInvoker)delegate { form.Picture2(image); });
            else
                form.Picture2(image);
        }

        private void ChangeProgress(double val) {
            if (form.InvokeRequired)
                form.Invoke((MethodInvoker)delegate { form.Progress(val); });
            else
                form.Progress(val);
        }

        private void BlockPanel(bool flag) {
            switch (flag) {
                case true when form.InvokeRequired:
                    form.Invoke((MethodInvoker)delegate { form.BlockPanel(); });
                    break;
                case true:
                    form.BlockPanel();
                    break;
                case false when form.InvokeRequired:
                    form.Invoke((MethodInvoker)delegate { form.UnblockPanel(); });
                    break;
                case false:
                    form.UnblockPanel();
                    break;
            }
        }
    }
}